import PlanReportView from "./PlanReportView";

export { PlanReportView };
export default PlanReportView;