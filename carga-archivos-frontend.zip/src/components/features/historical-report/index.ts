export { HistoricalReportView } from './HistoricalReportView';
export { HistoricalTable } from './HistoricalTable';

// Re-export modular components
export * from './components';